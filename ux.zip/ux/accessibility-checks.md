# Accessibility checks (WCAG 2.1 AA) & CI integration

This doc lists the core WCAG 2.1 AA checks to apply, suggested tests per component/page, and CI tooling to integrate.

## Core WCAG 2.1 AA checks (high level)
1. Perceivable
   - Text alternatives for non-text content (images, icons have alt or aria-hidden)
   - Captions and transcripts for media (video/audio)
   - Content must be adaptable and responsive (no info loss at different viewports)
   - Distinguishable: color contrast ratio >= 4.5:1 for normal text and 3:1 for large text

2. Operable
   - Keyboard accessibility for all interactive elements (tab order, focus visible)
   - No keyboard traps; modals trap and return focus correctly
   - Time limits: provide controls or warnings if time-limited
   - Seizure safety: avoid flashing content beyond thresholds

3. Understandable
   - Clear labels and instructions
   - Predictable navigation and UI behavior
   - Error identification and suggestions on forms

4. Robust
   - Proper use of ARIA, semantic HTML, and role attributes
   - Ensure compatibility with assistive technologies

---

## Component-level tests and checks

Button
- Tests:
  - Renders as `<button>` or `<a role="button">` with accessible name
  - Has visible focus state (test keyboard tabbing)
  - `aria-disabled` set when disabled
- Automated linters: `eslint-plugin-jsx-a11y` rules (interactive-supports-focus, button-has-type)

Input
- Tests:
  - Label association via `htmlFor`/`id`
  - `aria-invalid` and `aria-describedby` when error
  - Keyboard focus and screen-reader announcement of errors
- Automated linters: `eslint-plugin-jsx-a11y` (label-has-associated-control)
- Unit tests: `jest-axe` on form components

Card
- Tests:
  - If interactive, keyboard focusable and has accessible name via `aria-labelledby`
  - Non-informative decorative images marked `aria-hidden`
- Linters: `eslint-plugin-jsx-a11y` (no-autofocus, interactive-supports-focus)

Modal
- Tests:
  - Focus trap when open, return focus when closed
  - `role="dialog"` and `aria-modal="true"` with `aria-labelledby`
  - Escape key closes modal
- Tools: `@testing-library/user-event` for keyboard flows, `jest-axe` for accessibility assertions

Sidebar
- Tests:
  - `nav` semantic element with `aria-label`
  - Links reachable by keyboard; visible focus styles
  - Collapsible behavior accessible (aria-expanded on toggle)
- Linters: `eslint-plugin-jsx-a11y`

Header
- Tests:
  - Search input has label; notifications have aria-label and role
  - Avatar menu uses proper ARIA (`aria-haspopup`, `aria-expanded`) and keyboard handling
- Linters: `eslint-plugin-jsx-a11y`

---

## Page-level checks
- Landmark roles present (`header`, `nav`, `main`, `footer`)
- Skip-to-content link present
- Page titles and headings in logical order
- Color contrast audit for all text and UI controls

---

## Automated tools to include in CI
1. eslint-plugin-jsx-a11y (lint stage)
   - Catches common accessibility mistakes at build/PR time.

2. jest-axe (unit tests)
   - Run against rendered components to assert no violations for common pages/components.

3. axe-playwright / axe-puppeteer (end-to-end)
   - Run accessibility scans on critical pages in CI (login, dashboard, users list).

4. Pa11y or Lighthouse CI (performance & accessibility)
   - Periodically run Lighthouse CI for accessibility, performance, best-practices and SEO.

5. Storybook + @storybook/addon-a11y (developer experience)
   - Surface accessibility issues during component development.

---

## Example CI workflow
- Lint & unit tests (include `eslint-plugin-jsx-a11y` and `jest-axe` tests)
- Build static site and run `axe-playwright` checks against deployed preview
- Run Lighthouse CI for final acceptance

---

## Action items
- Add `eslint-plugin-jsx-a11y` to ESLint config and enable recommended rules.
- Create baseline `jest-axe` tests for core components.
- Add nightly/PR `axe-playwright` scans for critical routes.

End of accessibility checks doc.
