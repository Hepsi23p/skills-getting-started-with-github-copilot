# Design tokens — Test_Project

This file documents the core design tokens and provides CSS variable and Tailwind config snippets.

## Colors
- Primary: #0f62fe
- Secondary: #393939
- Accent: #ff7a59
- Background: #f7f9fb
- Surface: #ffffff
- Text-primary: #111827 (dark gray)
- Text-muted: #6b7280

## Typography
- Font family: Inter, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial
- Base font-size: 16px
- Heading weight scale: 700 (H1-H3), 600 (H4-H6)

## Spacing scale
- xs: 4px
- sm: 8px
- md: 16px
- lg: 24px
- xl: 32px

## Border radius
- radius-sm: 4px
- radius-md: 8px
- radius-lg: 12px

---

## CSS variables (place in `src/styles/tokens.css` or a global CSS file)

:root {
  /* Colors */
  --color-primary: #0f62fe;
  --color-secondary: #393939;
  --color-accent: #ff7a59;
  --color-background: #f7f9fb;
  --color-surface: #ffffff;
  --color-text: #111827;
  --color-muted: #6b7280;

  /* Typography */
  --font-sans: 'Inter', system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  --font-base-size: 16px;

  /* Spacing */
  --space-xs: 4px;
  --space-sm: 8px;
  --space-md: 16px;
  --space-lg: 24px;
  --space-xl: 32px;

  /* Radii */
  --radius-sm: 4px;
  --radius-md: 8px;
  --radius-lg: 12px;
}

/* Example utility tokens */
:root {
  --shadow-1: 0 1px 2px rgba(16,24,40,0.05);
  --shadow-2: 0 4px 12px rgba(16,24,40,0.08);
}

---

## Tailwind config snippets

Add or merge the following into your `tailwind.config.js` (extend theme):

```js
// tailwind.config.js
module.exports = {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#0f62fe',
        secondary: '#393939',
        accent: '#ff7a59',
        background: '#f7f9fb',
        surface: '#ffffff',
        text: '#111827',
        muted: '#6b7280',
      },
      spacing: {
        xs: '4px',
        sm: '8px',
        md: '16px',
        lg: '24px',
        xl: '32px',
      },
      borderRadius: {
        sm: '4px',
        md: '8px',
        lg: '12px',
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "-apple-system", "Segoe UI", "Roboto", "Helvetica Neue", "Arial"],
      },
      boxShadow: {
        'soft': '0 1px 2px rgba(16,24,40,0.05)',
        'elev': '0 4px 12px rgba(16,24,40,0.08)'
      }
    }
  },
  plugins: [],
};
```

Notes:
- If you prefer to use CSS variables in Tailwind, you can reference them in the `colors` map using `rgb(var(--color-primary-rgb) / <alpha-value>)` after exposing RGB variables.
- Make sure to import your `tokens.css` before Tailwind base in `src/index.css` so variables are available to custom CSS.

---

## How to import tokens

In `src/styles/tokens.css` (created alongside this doc), then in `src/index.css` put at the top:

```css
@import './styles/tokens.css';
@tailwind base;
@tailwind components;
@tailwind utilities;
```

This ensures CSS variables are available when components render.

---

## Quick token usage examples

- Use the primary color on a button: `className="bg-primary text-white"` (Tailwind) or `style={{ backgroundColor: 'var(--color-primary)' }}` for inline styles.
- Use spacing: `className="p-md"` if you map spacing tokens to Tailwind spacing scale. Otherwise use `p-4` etc. as appropriate.


---

End of design tokens.
