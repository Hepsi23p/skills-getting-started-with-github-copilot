# User Journey — Maya Lopez: View critical business metrics

## Scenario
Maya (Operations Manager) needs to quickly view the platform health and key business metrics after receiving an alert about a possible drop in conversions.

## High-level steps (user journey)
1. Entry: Maya receives an email or Slack alert and clicks the link to the admin dashboard.
2. Authentication: She signs in via SSO (or is already authenticated) and lands on the dashboard home.
3. At-a-glance: The dashboard shows an above-the-fold summary with health indicators and 3–4 key metrics (activation, conversion, task completion) with trend sparklines.
4. Drill-down: Maya clicks the conversion metric to open a drill-down panel with time range controls and top segments (device, region, campaign).
5. Investigate: She applies a 24-hour time filter and sees a spike in errors tied to a legacy API endpoint; an alert card links to the affected service.
6. Action: Maya creates a ticket or assigns the incident to the engineering lead directly from the drill-down, adding notes and priority.
7. Exit: Maya bookmarks the filtered view for later and logs out or navigates away.

## 6-Step Happy Path Flow (concise)
1. Click alert link → dashboard opens (authenticated)
2. Scan at-a-glance metrics (see conversion drop)
3. Click conversion card → open drill-down panel
4. Set time range to last 24 hours and apply
5. Identify root cause (legacy API errors) and create incident assignment
6. Bookmark view and close panel

## 3 Alternative / Error Flows to Design For
1. Authentication failure: SSO times out or MFA required. Design: show clear error, retry button, fallback login, and a contact support link.
2. Data lag / stale metrics: Dashboard shows cached data or incomplete ingestion. Design: surface "data last updated" timestamp, provide a refresh button and a lightweight explanation of data pipeline status.
3. Drill-down errors / API failure: Drill-down request fails or returns partial data. Design: show an inline error card with the failed request, suggested mitigations, and the option to export what data is available.

## Notes and Design Implications
- Above-the-fold must be compact and prioritized. Use tokens from `brand-guidelines.md` for spacing and color.
- Provide inline CTAs for creating incidents or assigning owners to reduce context switching.
- Ensure drill-downs are keyboard accessible and have proper ARIA labels.

## Next steps
- Create a quick wireframe for the dashboard home focusing on the above-the-fold metrics and drill-down interaction.
- Define the incident creation modal fields and API contract (adapter layer for legacy APIs).
