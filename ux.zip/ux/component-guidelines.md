# Component API docs — Reusable UI components

This doc lists 6 reusable components with brief API, states, and accessibility notes.

1. Button
- Props: `variant` ('primary'|'secondary'|'ghost'), `size` ('sm'|'md'|'lg'), `disabled` (bool), `onClick` (fn), `type` ('button'|'submit').
- States: default, hover, focus, active, disabled, loading
- Accessibility: use `<button>` element, include `aria-disabled` when disabled, provide focus-visible styles, include `aria-busy` when loading.
- Example: `<Button variant="primary" size="md" onClick={...}>Save</Button>`

2. Input
- Props: `id`, `name`, `value`, `onChange`, `placeholder`, `label`, `type` ('text'|'email'|'password'), `error` (string), `disabled`.
- States: default, focus, error, disabled
- Accessibility: associate `label` with input via `htmlFor` and `id`; expose `aria-invalid` when error, include `aria-describedby` to link to helper/error text.

3. Card
- Props: `title`, `children`, `footer`, `className`.
- States: default, hover, selected
- Accessibility: use `<section>` or `<article>` with `aria-labelledby` if title present.

4. Modal
- Props: `isOpen`, `onClose`, `title`, `children`, `size` ('sm'|'md'|'lg')
- States: open, closed, busy
- Accessibility: trap focus inside modal, set `aria-modal="true"` and role="dialog", provide `aria-labelledby` for title, close on ESC, return focus to trigger element.

5. Sidebar
- Props: `isCollapsed`, `items` (array of {label, href, icon}), `onToggle`
- States: expanded, collapsed
- Accessibility: `nav` element with `aria-label`, keyboard nav with focusable links, ensure skip link for main content.

6. Header
- Props: `onSearch`, `onToggleSidebar`, `notifications` (array), `user` (object)
- States: default, search active
- Accessibility: search input labeled, notification button with `aria-haspopup` if menu opens, keyboard accessible avatar menu.

## Implementation notes
- Prefer composition: build Button/Input/Card as primitive components with className prop to extend.
- Add unit tests and accessibility tests (axe) for each component.
