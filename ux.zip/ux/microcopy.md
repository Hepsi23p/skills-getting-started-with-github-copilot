# Microcopy — Test_Project (Brand voice: concise, confident, helpful)

Tone: concise, confident, helpful — use direct verbs, prioritize clarity, avoid jargon.

## Buttons
- Primary: "Save changes"
- Primary (confirm): "Create incident"
- Secondary: "Cancel"
- Secondary (quiet): "Dismiss"
- Tertiary: "View details"
- Action (bulk): "Apply"
- Small (table action): "Edit"

## Empty states
- Dashboard empty: "No recent activity. Check back later or refresh to load new data."
- Users list empty: "No users found. Try adjusting your filters or invite new users." (CTA: "Invite user")
- Reports library empty: "No saved reports yet. Create a report to track key metrics." (CTA: "Create report")
- Incidents empty: "No active incidents. System operating normally." (CTA: "View system status")

## Error messages
- Generic network error: "We couldn't load data. Check your connection and try again." (CTA: "Retry")
- Save failed: "Save failed. Please try again or contact support." (Details link: "Why did this fail?")
- Auth error: "Your session expired. Sign in again to continue." (CTA: "Sign in")
- Import error: "Import failed: invalid file format. Upload a CSV file with valid headers."
- Drill-down error: "We couldn't load this view. Try changing the date range or refresh." (CTA: "Refresh")

## Success messages
- Save success: "Changes saved." (optional undo)
- Incident created: "Incident created and assigned." (CTA: "View incident")
- User invited: "Invitation sent to {email}." (CTA: "Resend")
- Export ready: "Your export is ready." (CTA: "Download")

## Tooltips (short, < 80 characters)
- KPI card: "Click to drill down into this metric"
- Assign button: "Assign this incident to a teammate"
- Search: "Search by name, email, or ID"
- Export: "Export the current view as CSV"
- Filters: "Open filters"

## Microcopy rules
- Use sentence case for buttons and messages.
- Prioritize action-first language for CTAs.
- Keep tooltips under 80 characters and avoid punctuation unless necessary.

End of microcopy file.
