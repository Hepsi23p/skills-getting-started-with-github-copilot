# Low-Fidelity Wireframes — Test_Project Admin Dashboard

Pages included:
- Dashboard (Home)
- Users List
- User Detail (modal)
- Reports Library
- Incident Detail

---

## Dashboard (Home)

Header
- Left: logo
- Center: global search (users, reports)
- Right: notifications bell, user avatar

Sidebar (collapsible)
- Dashboard
- Users
- Reports
- Incidents
- Settings

Top KPI strip (cards)
- Card 1: Activation (value + sparkline)
- Card 2: Conversion (value + sparkline)
- Card 3: Task Completion (value + sparkline)
- Card 4: Revenue / custom metric

Alerts / Health panel
- Title: Recent critical alerts
- List: each alert has severity, time, service, quick action (assign)

Main content: Charts + Activity
- Row 1: Large chart (Conversion over time)
- Row 2: Two smaller charts (Funnel breakdown, Errors by service)
- Right rail: Activity feed + Quick actions

Mobile notes
- Header condensed: hamburger for sidebar, logo, avatar
- KPI strip becomes horizontal scroll or stacked vertically
- Charts stack vertically; right rail moves below main content

Spacing
- Use spacing tokens: md (16px) between sections, sm (8px) for chips, lg (24px) for page margins

---

## Users List

Header: same

Page Title: Users

Controls bar
- Search input (by name/email)
- Filters (status, role, created date)
- Actions: Import, Export, Create User

Table (rows)
- Columns: Name | Email | Role | Last Active | Status | Actions
- Row actions: Edit, Impersonate, More
- Bulk select checkbox + bulk actions toolbar appears when rows selected

Pagination / server-side
- Pagination controls bottom-right; page size selector bottom-left

Mobile notes
- Table collapses to card list: each user as stacked card with key fields and actions in a menu
- Search fixed to top; filters in collapsible panel

Spacing
- Table row height: md (56px), spacing between controls: sm (8px)

---

## User Detail (Modal)

Modal header: User name + close

Tabs: Overview | Activity | Support Tickets

Overview content
- Profile card: avatar, name, email, role, status, last login
- Actions: Edit, Reset Password, Suspend
- Activity mini-list: recent logins, key events

Edit form (inline or separate modal)
- Fields: name, email, role (select), status toggle
- Save / Cancel buttons

Mobile notes
- Modal takes full screen; tabs become top stacked sections

Spacing
- Form fields: sm vertical spacing, buttons grouped with md gap

---

## Reports Library

Page header: Reports

Controls
- Create Report button, search, filter by owner/date

List/grid of report cards
- Each card: title, owner, last run, preview chart, actions (open, export, share)

Report Builder (separate page/modal)
- Left: metric & dimension selector
- Center: visualization canvas (chart preview)
- Right: filters & saved view controls

Mobile notes
- Cards stacked; builder sections collapse into accordion panels

Spacing
- Cards: md gap between cards, card padding: md

---

## Incident Detail

Page/Modal header: Incident title, severity badge, status, assignee

Primary column
- Incident timeline: events, logs, comments
- Affected services list with status

Right column
- Incident actions: Assign, Change status, Add note, Link to user(s)
- Related reports / quick links

Mobile notes
- Timeline first; actions collapse into bottom sticky bar

Spacing
- Timeline items: sm spacing; columns stack at < 1024px

---

## Reusable components
- Header
- Responsive sidebar
- KPI card
- Chart card
- Table with server-pagination
- Modal

## Accessibility notes
- Ensure skip-to-content link in header
- Focus trap in modals, visible focus styles
- Color contrast per `brand-guidelines.md`

---

End of wireframes
