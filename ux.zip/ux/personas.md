# Personas — Admin Users (Test_Project)

## Persona 1: Maya Lopez
- Role: Operations Manager
- Bio: Maya manages day-to-day platform operations for a mid-sized product team. She reviews system alerts, monitors KPIs, and coordinates fixes with engineering.
- Goals:
  - Keep uptime and system health within SLAs.
  - Quickly identify regressions and assign issues.
  - Monitor conversion and activation trends.
- Frustrations:
  - Delays when dashboards are slow or data is stale.
  - Scattered alerts with poor context.
- Tech comfort: High — comfortable with dashboards, filters, and CSV exports.
- Key user story: As Maya, I want to see an at-a-glance health overview and recent critical alerts so I can triage incidents quickly.

## Persona 2: Daniel Kim
- Role: Product Analyst
- Bio: Daniel analyzes user behavior and conversion funnels. He runs ad-hoc queries, builds reports, and shares insights with stakeholders.
- Goals:
  - Access clean, exportable metric data and drill-downs.
  - Create and save filtered views for repeated analysis.
- Frustrations:
  - Inconsistent metric definitions and lack of segmentation tools.
  - Poor export formatting that requires manual cleanup.
- Tech comfort: Medium-High — proficient with analytics tools and SQL.
- Key user story: As Daniel, I want to save a filtered metric view and export the underlying table so I can include it in stakeholder reports.

## Persona 3: Aisha Patel
- Role: Support Lead (Admin)
- Bio: Aisha manages a small support team and uses the admin dashboard to look up user records and escalate issues.
- Goals:
  - Quickly find and update user accounts.
  - See recent support tickets and resolution status.
- Frustrations:
  - Slow or paginated user tables that make searches tedious.
  - Lack of keyboard shortcuts for common actions.
- Tech comfort: Medium — comfortable with web UIs and basic admin tools.
- Key user story: As Aisha, I want to search for a user by email and open an edit modal so I can resolve their issue during the support call.
