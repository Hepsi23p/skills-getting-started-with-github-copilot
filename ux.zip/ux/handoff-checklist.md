# Developer Handoff Checklist — Test_Project

## Overview
This checklist covers UI components, props/contracts, API endpoints with example responses, and acceptance criteria for critical flows.

---

## Component list & props/contracts

1. Header
- Props: `onSearch(query)`, `onToggleSidebar()`, `notifications` (array), `user` ({id,name,avatarUrl})
- Contracts:
  - `onSearch` invoked with a string on submit
  - `notifications` shape: [{id, title, body, createdAt, read}]
- Accessibility: search input has `id` and label; notification button has `aria-haspopup` and `aria-expanded` when menu open.

2. Sidebar
- Props: `items` (array), `isCollapsed` (bool), `onToggle`
- `items` shape: [{id,label,href,icon,active}]
- Accessibility: `nav` element with `aria-label`, toggle button with `aria-expanded`.

3. KpiCard
- Props: `title`, `value`, `change` (string), `sparkData` (array), `onClick`
- Contracts: `onClick` called when card clicked for drill-down
- Accessibility: `role="group"`, `aria-label` describing metric

4. ChartCard
- Props: `title`, `chartType`, `data`, `height`, `options`
- Contracts: Accepts data array and standard options (xKey, yKey)
- Accessibility: provide `aria-hidden` if decorative and include text summary below chart for screen readers

5. Table (Users)
- Props: `columns` (array), `rows` (array), `onSort`, `onPageChange`, `onRowAction`
- Contracts: columns: [{key,label,sortable}], rows: array of objects
- Accessibility: proper table semantics, `aria-sort` on headers

6. Modal
- Props: `isOpen`, `onClose`, `title`, `children`, `size`
- Behavior: trap focus, return focus on close, close on ESC
- Accessibility: `role="dialog"`, `aria-modal="true"`, `aria-labelledby` set

7. Button
- Props: `variant`, `size`, `disabled`, `loading`, `onClick`, `type`
- Accessibility: `aria-disabled` when disabled, `aria-busy` when loading

---

## API endpoints (examples)

Note: these are example endpoints. Replace base URL and auth headers as needed.

1. GET /api/dashboard/kpis
- Purpose: fetch values for KPIs
- Response:
```
{
  "activation": 1234,
  "conversion": 2.4,
  "taskCompletion": 85,
  "revenue": 12345
}
```

2. GET /api/alerts/recent
- Purpose: list recent critical alerts
- Response:
```
[{
  "id": "alert_1",
  "title": "Conversion drop detected",
  "service": "legacy-payments-api",
  "severity": "high",
  "count": 10,
  "createdAt": "2025-10-14T12:34:56Z"
}]
```

3. GET /api/users?search=&page=1&pageSize=25
- Response:
```
{
  "items": [{"id":"u1","name":"Jane","email":"jane@example.com","role":"Admin","lastActive":"2025-10-14T10:00:00Z"}],
  "total": 1234
}
```

4. POST /api/incidents
- Purpose: create incident
- Payload:
```
{ "title":"Conversion drop", "severity":"high", "assigneeId":"u2", "notes":"Investigating" }
```
- Response:
```
{ "id":"inc_123","status":"open","createdAt":"2025-10-14T12:40:00Z" }
```

5. POST /api/reports/export
- Purpose: request CSV export for a report
- Payload: `{ "reportId":"r1","format":"csv" }`
- Response:
```
{ "exportId":"exp_1","status":"ready","downloadUrl":"/downloads/exp_1.csv" }
```

---

## Acceptance criteria (per flow)

Dashboard
- KPIs display correct values from `/api/dashboard/kpis`.
- Clicking KPI calls drill-down handler with the metric id.
- Recent alerts displayed and action buttons call correct endpoints.
- Page passes core accessibility checks and loads within performance budget (<2s median).

Users List
- Search returns appropriate results; pagination works.
- Edit action opens modal with populated data.
- Table supports keyboard navigation and ARIA attributes.

Incident creation
- POST to `/api/incidents` returns success and new incident appears in list.
- Modal traps focus and returns focus on close.

Reports export
- POST `/api/reports/export` enqueues export; when status ready, download link available.

---

## Developer handoff checklist (steps)
1. Review `Design/ux` docs: wireframes, tokens, component-guidelines, microcopy.
2. Merge Tailwind tokens into `tailwind.config.js` and import `tokens.css`.
3. Implement components based on contracts; add Storybook stories.
4. Add unit tests and `jest-axe` accessibility tests for each component.
5. Wire API calls using provided endpoints; implement adapter for legacy APIs if needed.
6. Add E2E accessibility checks (axe-playwright) for critical pages.
7. Run performance checks (Lighthouse CI) and ensure acceptance criteria are met.

---

## Figma import plan (quick)
1. Create a new Figma file named "Test_Project UI Kit".
2. For each page in `Design/ux/wireframes.md`, create a top-level frame (Desktop 1440x1024, Mobile 375x812).
3. Copy the wireframe layout into frames using rectangles, text layers, and repeat grids for lists.
4. Create components for Header, Sidebar, KPI card, Table row, Modal, Button.
5. Add tokens: colors, typography, spacing as global styles in Figma (colors & text styles).
6. Export assets (icons, avatars) and link images to placeholders.
7. Group and name frames for developer handoff; add links to `Design/ux` docs.

Tips:
- Use auto-layout for cards and lists to make resizing easier.
- Create a components page in Figma where devs can inspect CSS properties.

---

End of handoff checklist.
