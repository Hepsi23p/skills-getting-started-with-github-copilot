# Moderated Usability Test Script — Maya (Operations Manager)

Purpose: Validate that Maya can quickly identify a conversion drop, drill into the metric, and create an incident assignment.

Participants: 7 tasks, moderated, think-aloud protocol, 30–45 minutes per session.

## Pre-test setup
- Moderator introduces themselves, purpose, and asks for consent to record the session.
- Brief participant background questions (role, experience with dashboards).
- Ensure screen-sharing is working and the prototype (or staging site) is loaded.

## Tasks (7)
### Task 1 — Locate dashboard and identify KPIs
- Scenario: "You received an alert about a possible conversion drop. Open the dashboard and tell me which KPI you would check first."
- Success criteria: Participant locates dashboard and identifies the Conversion KPI within 30 seconds.
- Post-task question: "Was it clear where to find the key metrics? If not, what was confusing?"

### Task 2 — Drill into conversion metric
- Scenario: "Click the Conversion card to view a detailed drill-down for the past 24 hours."
- Success criteria: Participant opens drill-down and sets time range to 24 hours; drill panel shows segmentation controls.
- Post-task question: "Was the drill-down information sufficient to investigate the issue?"

### Task 3 — Identify root cause indicators
- Scenario: "Using the drill-down, find an indicator that points to a likely root cause (e.g., API errors or a specific campaign)."
- Success criteria: Participant identifies the legacy API errors or appropriate segment as the primary indicator.
- Post-task question: "How confident are you in this finding? Any additional data you'd need?"

### Task 4 — Create an incident and assign
- Scenario: "Create an incident from the drill-down, add a brief note, and assign it to the engineering lead."
- Success criteria: Participant creates incident, adds note, assigns user; incident appears in the incidents list or confirmation appears.
- Post-task question: "Was creating and assigning the incident straightforward? Any missing fields?"

### Task 5 — Save filtered view
- Scenario: "Save the filtered 24-hour view for future reference."
- Success criteria: Participant saves view and can find it in 'Saved reports' or confirms the view is bookmarked.
- Post-task question: "Was saving the view easy? Where would you expect to find saved views?"

### Task 6 — Search and edit a user
- Scenario: "Search for a user by email and open their profile to change their role to 'Support'."
- Success criteria: Participant finds user via search in <60s, opens detail modal, changes role, and saves.
- Post-task question: "Was the search and edit flow efficient? Any improvements?"

### Task 7 — Export a report
- Scenario: "Export the conversion drill-down data as CSV for the last 24 hours."
- Success criteria: Participant initiates export and sees a confirmation or download link.
- Post-task question: "Was it clear how exports work? Any missing export options you'd expect?"

## Post-test questions (after all tasks)
1. Overall, how easy or difficult was it to complete the tasks? (1–5)
2. What was the most confusing moment during the session?
3. Which feature would you use most frequently?
4. Do you have any concerns about accessibility or speed?
5. Any final suggestions or features you'd like to see?

## Metrics to collect
- Task success (binary) and time on task
- Errors observed and severity
- Post-task confidence (self-reported)
- Qualitative notes from think-aloud

---

# Recruitment screener (10 participants)

We are recruiting Operations Managers or similar (admins) to participate in a 30–45 minute moderated usability test. Target: 10 participants.

Screening questions (yes/no / short answer):
1. Are you currently an Operations Manager, Product Analyst, Support Lead, or similar role? (Yes/No)
2. Do you use dashboards or admin panels in your daily work? (Yes/No)
3. How many times per week do you use analytics or admin tools? (e.g., 0–1, 2–5, 6+)
4. Are you comfortable using web-based admin tools and CSV exports? (Yes/No)
5. Have you managed incidents or assigned issues to engineering teams before? (Yes/No)
6. Do you have experience using SSO or enterprise login systems? (Yes/No)
7. Are you available for a 30–45 minute moderated session in the next two weeks? (Yes/No)
8. What is your preferred time window for sessions? (morning/afternoon/evening)
9. Are you willing to be recorded (screen + audio) for research purposes? (Yes/No)
10. Please provide your contact email and company (for scheduling).

Selection notes:
- Aim for diversity in company size and domain; prefer participants who are frequent dashboard users (2+ times/week).
- Offer a small stipend as thank-you (e.g., $50–100 USD).

End of usability test script and screener.
