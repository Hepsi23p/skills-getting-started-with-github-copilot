# Information Architecture — Test_Project Admin Dashboard

- Dashboard (Home)
  - Purpose: High-level operational and business overview for admins.
  - Components:
    - Header (global) — notifications, user profile, quick actions
    - Left Sidebar — navigation: Dashboard, Users, Reports, Incidents, Settings
    - Top KPI strip — key metrics (activation, conversion, task completion)
    - Alerts / Health panel — service status, recent critical alerts
    - Activity feed — recent actions, deployments, incidents
    - Quick filters / time range selector

- Users
  - Purpose: Search, view, edit, and manage user accounts.
  - Pages/Components:
    - Users List — search, filters, pagination, bulk actions
    - User Detail Modal/Page — profile, activity, tickets, edit form
    - Import / Export — CSV upload and download

- Reports
  - Purpose: Saved metric views, custom reports, and exports.
  - Pages/Components:
    - Reports Library — list of saved reports and views
    - Report Builder — metric selection, segmentation, visualization
    - Report Detail — interactive charts, export options

- Incidents
  - Purpose: Track system incidents, assign owners, and log remediation steps.
  - Pages/Components:
    - Incidents List — active/closed incidents, filters by severity
    - Incident Detail — timeline, affected services, assignees, comments
    - Create Incident Modal — title, severity, assignee, notes

- Settings
  - Purpose: Configure system-level settings and integrations.
  - Pages/Components:
    - Integrations — alerting, SSO, data connectors
    - Permissions — admin roles and access control
    - Branding — theme tokens (connects to `brand-guidelines.md`)
    - Performance & Data — data retention, refresh intervals

- Help / Support
  - Purpose: Documentation, troubleshooting steps, contact support.
  - Components:
    - Docs quick links
    - Contact support modal
    - System status page (external link)

## Cross-cutting components
- Global header
- Responsive sidebar (collapsible)
- Cards & KPI components (reusable)
- Table component with server-side pagination
- Modal component (for edits/create)
- Accessibility helpers (focus trap, skip link)

## Notes
- Prioritize Dashboard home for fast access to health + key KPIs.
- Keep actions inline (create incident, assign owner) to reduce context switching.
- Design components to support server-side rendering for SEO/perf via Next.js.
